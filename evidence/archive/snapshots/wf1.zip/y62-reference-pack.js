(function(root,factory){const v=factory();if(typeof module==='object'&&module.exports)module.exports=v;else root.Y62_REFERENCE_PACK=v;})(typeof globalThis!=='undefined'?globalThis:this,function(){return {
 schemaVersion:'0.26.0',vehicleId:'nissan-y62-warrior-2025',vehicleIdentity:{year:2025,series:'Series 5 / MY25',make:'Nissan',model:'Patrol Y62',trim:'Warrior by Premcar',paint:'Black Obsidian'},
 usageBasis:'Owner-supplied to the PRO4X4 Rig Builder project as primary authenticity/reference material. Owner-source files may be used for internal canonical-render development; any external listing imagery remains reference-only unless separate rights are recorded.',
 references:[
  {id:'OWNER-Y62-F34-01',file:'references/y62-owner/IMG_4030.jpeg',sourceType:'owner-supplied',rights:'owner-project-approved',view:'front34',quality:'primary',width:1536,height:1152,sha256:'400a6e3f7fddeb5dba175173491ddd2bab62c0cea6fd286b5c4e6119d9a72fdc'},
  {id:'OWNER-Y62-F34-02',file:'references/y62-owner/IMG_3762.jpeg',sourceType:'owner-supplied',rights:'owner-project-approved',view:'front34',quality:'support',width:1536,height:1152,sha256:'5a3f5209582446cb21622c7c4a5b2741437c55095c7ce7276a9c22e6adb1dfd4'},
  {id:'OWNER-Y62-FRONT-01',file:'references/y62-owner/IMG_4028.jpeg',sourceType:'owner-supplied',rights:'owner-project-approved',view:'front',quality:'primary',width:1152,height:1536,sha256:'96e9d873a7fc7eeff48a95eab46896e4572549c8e6a8e286e631a269d42cfb8e'},
  {id:'OWNER-Y62-FRONT-02',file:'references/y62-owner/IMG_4512.jpeg',sourceType:'owner-supplied',rights:'owner-project-approved',view:'front',quality:'support',width:1536,height:1152,sha256:'8fabad7df166ce1ac3e95b5fe38f13572e1d86e2c2d21343917a0842321d5739'},
  {id:'OWNER-Y62-REAR34-01',file:'references/y62-owner/IMG_4540.jpeg',sourceType:'owner-supplied',rights:'owner-project-approved',view:'rear34',quality:'primary',width:1536,height:1152,sha256:'747c9edf7b39fca2cb9fa9dde0bf329cdbec8dc2c08643d873317b50c27d28e2'},
  {id:'OWNER-Y62-REAR-01',file:'references/y62-owner/IMG_4508.jpeg',sourceType:'owner-supplied',rights:'owner-project-approved',view:'rear',quality:'primary',width:1152,height:1536,sha256:'a72cb38fc92c95afd86c6eab513904d056ae80b3123ccea64eea9cbd5c01627a'},
  {id:'OWNER-Y62-DETAIL-01',file:'references/y62-owner/IMG_6320.jpeg',sourceType:'owner-supplied',rights:'owner-project-approved',view:'front34-detail',quality:'support',width:1080,height:1920,sha256:'5ffb0cb1465237dd8c8b021437037860562720026f74653247585495548af746'},
  {id:'OWNER-Y62-DESIGNBOARD-01',file:'references/y62-owner/5E67BCCD-7780-4D9E-B83F-418F253D64B3.jpeg',sourceType:'owner-supplied',rights:'owner-project-approved',view:'design-reference',quality:'support',width:1536,height:864,sha256:'736d43c3cd14ffce043549b7d9abf5f8e6da0b57e2d451543ce4ba9fa3bfa747'},
  {id:'OWNER-Y62-FRONT-03',file:'references/y62-owner/IMG_3745.jpeg',sourceType:'owner-supplied',rights:'owner-project-approved',view:'front',quality:'support',width:1152,height:1536,sha256:'dea9b9b35332c5d4659e6d40eab38cb0786fce8c2dbe79d7b8ca48aa65e3ab58'}
 ],
 gaps:[{view:'side',severity:'required',note:'No clean square-on raw side-profile owner photo in current pack. Multi-reference reconstruction may be used for canonical render only if geometry review passes; direct third-party photo promotion is prohibited.'}],
 status:'reference-approved'
};});
